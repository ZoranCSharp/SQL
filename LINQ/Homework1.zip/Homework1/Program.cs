using System;
using System.Linq;

class prvi
{
    static void Main()
    {
        int[] n1 = {
               100,0,3,6,5,4,8,-5,-7,-9,-111,254,347,987
            };

        Console.Write("\nLINQ : Using multiple WHERE clause to find the positive numbers within the list : ");       

        var nQuery =
        from VrNum in n1
        where VrNum > 0
        where VrNum < 1000
        select VrNum;
        Console.Write("\nThe numbers within the range of 1 to 11 are : \n");
        foreach (var VrNum in nQuery)
        {
            Console.Write($" {VrNum} " );
        }
        Console.Write("\n\n");
    }
}
