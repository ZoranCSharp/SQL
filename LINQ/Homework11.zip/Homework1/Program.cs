using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class selecting
{
    static void Main(string[] args)
    {

        List<string> listOfString = new List<string>();
        listOfString.Add("micro");
        listOfString.Add("bottle");
        listOfString.Add("observe");
        listOfString.Add("politics");
        listOfString.Add("goooo");

        
        var result = from y in listOfString
                       select y;

        Console.Write("Here is the list of items : \n");
        foreach (var tchar in result)
        {
            Console.WriteLine($"Char: {tchar} ");
        }
        Console.WriteLine("Enter first parameter:");
        int a = int.Parse(Console.ReadLine());
        Console.WriteLine("\n");
        Console.WriteLine("Enter second parameter:");
        int b = int.Parse(Console.ReadLine());
        Console.WriteLine("\n");

        listOfString.RemoveRange(a, b);

        var _result = from z in listOfString
                      select z;
        Console.Write($"\nHere is the list after removing the three items starting from the item index {a} from the list {b} : \n");
        foreach (var rChar in _result)
        {
            Console.WriteLine($"Char: {rChar} ");
        }

        Console.ReadLine();
    }
}
