using System;
using System.Linq;
using System.Collections.Generic;

class eight
{
    static void Main(string[] args)
    {

        
        string strNew;

        Console.Write("Input the string with uppercase word: ");
        strNew = Console.ReadLine();

        var reader = WordFilt(strNew);

        Console.Write("\nThe UPPER CASE words are :\n ");

        foreach (string search in reader)
        {
            Console.WriteLine(search);
        }
        Console.ReadLine();
    }

    static IEnumerable<string> WordFilt(string mystr)
    {
        var upWord = mystr.Split(' ')
                    .Where(x => String.Equals(x, x.ToUpper(),
                    StringComparison.Ordinal));

        return upWord;

    }
}
