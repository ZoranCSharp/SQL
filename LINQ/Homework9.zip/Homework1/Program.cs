using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Students
{
    public string StuName { get; set; }
    public int GrPoint { get; set; }
    public int StuId { get; set; }

    public List<Students> students()
    {
        List<Students> stulist = new List<Students>();
        stulist.Add(new Students { StuId = 1, StuName = " Prle ", GrPoint = 1000 });
        stulist.Add(new Students { StuId = 2, StuName = "Srle", GrPoint = 300 });
        stulist.Add(new Students { StuId = 3, StuName = "Mika", GrPoint = 500 });
        stulist.Add(new Students { StuId = 4, StuName = "Kika", GrPoint = 500 });
        stulist.Add(new Students { StuId = 5, StuName = "Proka", GrPoint = 800 });
       
        return stulist;
    }
}
class LinqExercise14
{
    static void Main(string[] args)
    {
        Students e = new Students();

               
        Console.Write("Which maximum grade point(1st, 2nd, 3rd, ...) you want to find (Numbers only!!!)  : ");
        int grPointRank = Convert.ToInt32(Console.ReadLine());
        Console.Write("\n");

        var stulist = e.students();
        var student = (from stud in stulist
                        group stud by stud.GrPoint into g
                        orderby g.Key descending
                        select new
                        { StuRecord = g.ToList() }).ToList();
        //-1 because list starts from 0
        student[grPointRank - 1].StuRecord
            .ForEach(i => Console.WriteLine($" Id : {i.StuId},  Name : {i.StuName},  Grade Point : {i.GrPoint}"));

        
    }
}
