using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class findall
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter 10 numbers: \n");
        List<int> list = new List<int>();
        for(int i = 0; i < 10; i++)
        list.Add(int.Parse(Console.ReadLine()));

        Console.WriteLine("Enter search value: \n");
        int y = int.Parse(Console.ReadLine());

        Console.WriteLine($"Numbers greater than {y} are: \n");

        List<int> search = list.FindAll(x => x > y? true:false);

        foreach(var numbers in search)
        {
            Console.WriteLine($"{numbers}");
        }
        

    }
}
