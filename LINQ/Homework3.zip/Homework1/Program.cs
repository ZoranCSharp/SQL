using System;
using System.Linq;
using System.Collections.Generic;

class drugi
{
    static void Main(string[] args)
    {
        // code from DevCurry.com
        var arr1 = new[] { "Monday", "Thuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

        Console.Write("\nLINQ : Display days in week : ");
        
        var sqDa = from string str in arr1                  
                   select str;

        foreach (var a in sqDa)
            Console.WriteLine(a);

        Console.ReadLine();
    }
}