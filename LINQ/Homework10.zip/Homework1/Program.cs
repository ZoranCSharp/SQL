using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class removing
{
    static void Main(string[] args)
    {

        List<string> listOfString = new List<string>();
        listOfString.Add("mark");
        listOfString.Add("notepad");
        listOfString.Add("optical");
        listOfString.Add("prime");
        listOfString.Add("quit");


       
        var _result1 = from y in listOfString
                       select y;
        Console.Write("Here is the list of items : \n");

        foreach (var tchar in _result1)
        {
            Console.WriteLine($"Char: {tchar} ");
        }

        listOfString.RemoveAll(en => en == "quit");


        var _result = from z in listOfString
                      select z;

        Console.Write("\nHere is the list after removing item 'quit' from the list : \n");
        foreach (var rChar in _result)
        {
            Console.WriteLine($"Char: {rChar} ");
        }

        Console.ReadLine();
    }
}
