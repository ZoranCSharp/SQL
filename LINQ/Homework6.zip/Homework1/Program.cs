using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class greaterthan
{
    static void Main(string[] args)
    {
        List<int> list = new List<int>();
        list.Add(200);
        list.Add(100);
        list.Add(20);
        list.Add(50);
        list.Add(10);
        list.Add(500);

        Console.WriteLine("The list of numbers are: ");

        foreach(var numbers in list)
        {
            Console.WriteLine($"{numbers}");
        }

        Console.WriteLine("Numbers greater than 80 are: \n");

        List<int> search = list.FindAll(x => x > 80? true:false);

        foreach(var numbers in search)
        {
            Console.WriteLine($"{numbers}");
        }
        

    }
}
