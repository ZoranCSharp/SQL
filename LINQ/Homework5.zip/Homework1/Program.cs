using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class cities
{
    static void Main(string[] args)
    {
        string chst, chen;
        char ch;
        string[] cities =
        {
                "ROME","LONDON","NAIROBI","CALIFORNIA","ZURICH","NEW DELHI","AMSTERDAM","ABU DHABI", "PARIS"
            };
              
        Console.Write("\nThe cities are : 'ROME','LONDON','NAIROBI','CALIFORNIA','ZURICH','NEW DELHI','AMSTERDAM','ABU DHABI','PARIS' \n");

        Console.Write("\nInput starting character for the string : ");
        ch = (char)Console.Read();
        chst = ch.ToString();
        Console.Write("\nInput ending character for the string : ");
        ch = (char)Console.Read();
        chen = ch.ToString();


        var _result = from x in cities
                      where x.StartsWith(chst)
                      where x.EndsWith(chen)
                      select x;
        Console.Write("\n\n");
        foreach (var city in _result)
        {
            Console.Write($"The city starting with {chst} and ending with {chen} is : {city} \n");
        }

        Console.ReadLine();
    }
}
