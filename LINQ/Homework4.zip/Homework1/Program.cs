using System;
using System.Linq;
using System.Collections.Generic;

class numberfreq
{
    static void Main(string[] args)
    {
        int[] nums = new int[] { 200,100,200,300,500,3,2,4,7,-1,-5,-1,350 };

        Console.Write("------------------------------------------------\n");
        Console.Write("The numbers in the array are :\n");
        Console.Write("200,100,200,300,500,3,2,4,7,-1,-5,-1,350 \n");
        Console.Write("------------------------------------------------\n");

        var num = from number in nums
                  group number by number into newNums
                  select newNums;

        Console.Write("Number" + "\t" + "Frequency" + "\t" + "Number*Frequency" + "\n");
        Console.Write("------------------------------------------------\n");

        foreach (var arrEle in num)
        {
            Console.WriteLine(arrEle.Key + "\t" + arrEle.Sum() + "\t\t\t" + arrEle.Count());
        }
        Console.Write("------------------------------------------------\n");
        Console.WriteLine();
    }
}
